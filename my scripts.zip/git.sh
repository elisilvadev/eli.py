#!/bin/bash
############################################################
#							   #
# git.sh - Baixa repositorios do github compactados em zip #
#							   #
#  Versão:						   #
#   1.0 - 04/10/2019 Dheisom Gomes			   #
#    Projeto iniciado					   #
#							   #
############################################################

SITE="${1}"

baixar(){
LINK="${SITE}/archive/master.zip"
NOME="$(echo "${SITE##*/}")"
echo -e "\e[32mBaixando arquivo...\e[0m"
wget -q --show-progress -c "${LINK}" -O "${NOME}.zip"
if [ "$?" -gt "0" ];then
	echo -e "\e[31mFalha ao baixar zip\e[0m"
	exit 1
fi
echo -e "\e[32mArquivo zip baixado\e[0m"
}

case "${SITE}" in
	'')
		echo "use: $0 <link>"
		echo "Baixe repositorios do github em formato zip"
		;;
	*)
		GIT="$(echo "${SITE##*://}")"
		GIT="$(echo "${GIT%.com*}")"
		if [ "${GIT}" == "github" -o "www.github" ];then
			echo -n ''
			baixar
		else
			echo -e "\e[31mO link que você colocou não é do github\e[0m"
		fi
		;;
esac
