with open ("netvirtual1.txt","w")as stream:
    for e in range (11111110,22222220,10):
        print(e,file = stream)
with open ("netvirtual2.txt","w")as stream:
    for e in range (22222220,33333330,10):
        print(e,file = stream)
with open ("netvirtual3.txt","w")as stream:
    for e in range (33333330,44444440,10):
        print(e,file = stream)
with open ("netvirtual4.txt","w")as stream:
    for e in range (44444440,55555550,10):
        print(e,file = stream)
with open ("netvirtual5.txt","w")as stream:
    for e in range (55555550,66666660,10):
        print(e,file = stream)
with open ("netvirtual6.txt","w")as stream:
    for e in range (66666660,77777770,10):
        print(e,file = stream)
        print(e)
with open ("netvirtual7.txt","w")as stream:
    for e in range (77777770,88888880,10):
        print(e,file = stream)
with open ("netvirtual8.txt","w")as stream:
    for e in range (88888880,99999990,10):
        print(e,file = stream)
print('---fim---')
